import { AuthModule } from '@controller/auth/auth.module';
import { BillingTypeModule } from '@controller/billing-type/billing-type.module';
import { CenterTypeModule } from '@controller/center-type/center-type.module';
import { CenterModule } from '@controller/center/center.module';
import { ChassisDestinationModule } from '@controller/chassis-destination/chassis-destination.module';
import { ChassisStateModule } from '@controller/chassis-state/chassis-state.module';
import { ChassisModule } from '@controller/chassis/chassis.module';
import { LockStateModule } from '@controller/lock-state/lock-state.module';
import { LockModule } from '@controller/lock/lock.module';
import { UsersModule } from '@controller/users/users.module';
import { AppLoggerMiddleware } from '@core/middlewares/logger.middleware';
import { LoggerModule } from '@core/services/logger/logger.module';
import environment from '@environments/environment';
import { MiddlewareConsumer, Module } from '@nestjs/common';
import { ConfigModule, ConfigService } from '@nestjs/config';
import { TypeOrmModule } from '@nestjs/typeorm';

@Module({
  imports: [
    ConfigModule.forRoot({ isGlobal: true, load: [environment] }),
    TypeOrmModule.forRootAsync({
      imports: [ConfigModule],
      useFactory: (config: ConfigService) => config.get('database'),
      inject: [ConfigService],
    }),
    UsersModule,
    AuthModule,
    ChassisStateModule,
    LockStateModule,
    ChassisDestinationModule,
    LockModule,
    ChassisModule,
    BillingTypeModule,
    CenterTypeModule,
    CenterModule,
    LoggerModule,
  ],
  controllers: [],
  providers: [],
})
export class AppModule {
  configure(consumer: MiddlewareConsumer) {
    consumer.apply(AppLoggerMiddleware).forRoutes('*');
  }
}
