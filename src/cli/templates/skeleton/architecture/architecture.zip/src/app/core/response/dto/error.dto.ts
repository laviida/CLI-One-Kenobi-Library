export interface ErrorDTO {
  name: string;
  message: string | Array<string>;
}
