type ExcludeFunctionPropertyNames<T> = Pick<
  T,
  {
    [K in keyof T]: T[K] extends () => void ? never : K;
  }[keyof T]
>;

export interface EntityQuery<T> {
  where?: Partial<Record<keyof ExcludeFunctionPropertyNames<T>, any>>;
  limit?: number;
  orFail?: boolean;
}
