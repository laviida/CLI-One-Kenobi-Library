import { UsersModule } from '@controller/users/users.module';
import { forwardRef, Module } from '@nestjs/common';
import { JwtPasswordStrategy } from './password/jwt-password.strategy';
import { JwtRefreshStrategy } from './refresh/jwt-refresh.strategy';
import { JwtUserStrategy } from './user/jwt-user.strategy';

@Module({
  imports: [forwardRef(() => UsersModule)],
  controllers: [],
  providers: [JwtUserStrategy, JwtRefreshStrategy, JwtPasswordStrategy],
  exports: [JwtUserStrategy, JwtRefreshStrategy, JwtPasswordStrategy],
})
export class JwtModule {}
