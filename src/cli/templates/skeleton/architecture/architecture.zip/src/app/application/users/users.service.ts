import { RegisterDto } from '@controller/auth/dto/register.dto';
import { UpdateUserDto } from '@controller/users/dto/update-user.dto';
import { User } from '@controller/users/entities/user.entity';
import { EntityQuery } from '@core/database/dto/entity-query.dto';
import { UsersDomainService } from '@domain/users/users.domain';
import { Injectable } from '@nestjs/common';

@Injectable()
export class UsersService {
  constructor(private usersDomainService: UsersDomainService) {}

  create(createUserDto: RegisterDto) {
    return this.usersDomainService.create(createUserDto);
  }

  update(updateUserDto: UpdateUserDto) {
    return this.usersDomainService.update(updateUserDto.id, updateUserDto);
  }

  remove(id: number) {
    return this.usersDomainService.remove(id);
  }

  find(options?: EntityQuery<User>) {
    return this.usersDomainService.find(options ?? {});
  }
}
