import { UpdateUserDto } from '@controller/users/dto/update-user.dto';
import { UserPageOptionsDto } from '@controller/users/dto/user-pagination-options.dto';
import { User } from '@controller/users/entities/user.entity';
import { EntityQuery } from '@core/database/dto/entity-query.dto';
import { PageDto } from '@core/database/dto/page.dto';
import { PageMetaDto } from '@core/database/dto/pagination-meta.dto';
import { PageOptionsDto } from '@core/database/dto/pagination-options.dto';
import { UsersDomainService } from '@domain/users/users.domain';
import { Injectable } from '@nestjs/common';
import { map } from 'rxjs';

@Injectable()
export class UsersService {
  constructor(private usersDomainService: UsersDomainService) {}

  create(createUserDto: Partial<User>) {
    return this.usersDomainService.create(createUserDto);
  }

  update(updateUserDto: UpdateUserDto) {
    return this.usersDomainService.update(updateUserDto.id, updateUserDto);
  }

  remove(id: number) {
    return this.usersDomainService.remove(id);
  }

  find(options?: EntityQuery<User>) {
    return this.usersDomainService.find(options ?? {});
  }

  paginate(pageOptionsDto: UserPageOptionsDto) {
    return this.usersDomainService.paginate(pageOptionsDto).pipe(
      map(({ itemCount, entities }) => {
        const pageMetaDto = new PageMetaDto({ itemCount, pageOptionsDto });
        return new PageDto(entities, pageMetaDto);
      }),
    );
  }
}
