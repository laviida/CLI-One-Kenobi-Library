export interface UserToken {
  accessToken: string;
  refreshToken: string;
}
