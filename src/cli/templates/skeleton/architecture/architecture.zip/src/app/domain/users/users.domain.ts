import { UpdateUserDto } from '@controller/users/dto/update-user.dto';
import { UserPageOptionsDto } from '@controller/users/dto/user-pagination-options.dto';
import { User } from '@controller/users/entities/user.entity';
import { EntityQuery } from '@core/database/dto/entity-query.dto';
import { PageOptionsDto } from '@core/database/dto/pagination-options.dto';
import { ErrorDTO } from '@core/response/dto/error.dto';
import { HttpException, HttpStatus, Injectable } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { catchError, forkJoin, from, map } from 'rxjs';
import { EntityNotFoundError, Repository } from 'typeorm';

@Injectable()
export class UsersDomainService {
  constructor(
    @InjectRepository(User)
    private userRepository: Repository<User>,
  ) {}

  create(createUserDto: Partial<User>) {
    return from(this.userRepository.save(createUserDto));
  }

  update(id: number, updateUserDto: UpdateUserDto) {
    return from(this.userRepository.save({ id, ...updateUserDto }));
  }

  remove(id: number) {
    return from(this.userRepository.delete({ id }));
  }

  paginate(pageOptionsDto: UserPageOptionsDto) {
    const queryBuilder = this.userRepository.createQueryBuilder('user');

    queryBuilder
      .orderBy(`user.${pageOptionsDto.orderBy}`, pageOptionsDto.order)
      .skip(pageOptionsDto.skip)
      .take(pageOptionsDto.take);

    return forkJoin([
      queryBuilder.getCount(),
      queryBuilder.getRawAndEntities(),
    ]).pipe(
      map(([itemCount, { entities }]) => {
        return { itemCount, entities };
      }),
    );
  }

  find(options: EntityQuery<User>) {
    return from(
      this.userRepository.find({
        where: options.where,
        take: options.limit,
      }),
    ).pipe(
      map((users: Array<User>) => {
        if (options.orFail && users.length === 0)
          throw new EntityNotFoundError(
            User,
            `${User.name} entities not found. Filtered by: ${Object.keys(
              options.where ?? [],
            ).map((k) => `${k.toUpperCase()} (${k}: ${options.where[k]}), `)}`,
          );
        if (users.length === 0 && options.limit === 1) return null;
        return options.limit === 1 ? users[0] : users;
      }),
      catchError((e: HttpException) => {
        if (e instanceof EntityNotFoundError)
          throw new HttpException(
            { name: e.name, message: e.message } as ErrorDTO,
            HttpStatus.NOT_FOUND,
            { cause: e },
          );
        throw e;
      }),
    );
  }
}
