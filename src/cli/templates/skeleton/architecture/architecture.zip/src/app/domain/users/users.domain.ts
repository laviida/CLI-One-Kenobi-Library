import { UpdateUserDto } from '@controller/users/dto/update-user.dto';
import { User } from '@controller/users/entities/user.entity';
import { EntityQuery } from '@core/database/dto/entity-query.dto';
import { ErrorDTO } from '@core/response/dto/error.dto';
import { HttpException, HttpStatus, Injectable } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { catchError, from, map } from 'rxjs';
import { EntityNotFoundError, Repository } from 'typeorm';

@Injectable()
export class UsersDomainService {
  constructor(
    @InjectRepository(User)
    private userRepository: Repository<User>,
  ) {}

  create(createUserDto: Partial<User>) {
    return from(this.userRepository.save(createUserDto));
  }

  update(id: number, updateUserDto: UpdateUserDto) {
    return from(this.userRepository.save({ id, ...updateUserDto }));
  }

  remove(id: number) {
    return from(this.userRepository.delete({ id }));
  }

  find(options: EntityQuery<User>) {
    return from(
      this.userRepository.find({
        where: options.where,
        take: options.limit,
      }),
    ).pipe(
      map((users: Array<User>) => {
        if (options.orFail && users.length === 0)
          throw new EntityNotFoundError(
            User,
            `${User.name} entities not found. Filtered by: ${Object.keys(
              options.where ?? [],
            ).map((k) => `${k.toUpperCase()} (${k}: ${options.where[k]}), `)}`,
          );
        if (users.length === 0 && options.limit === 1) return null;
        return options.limit === 1 ? users[0] : users;
      }),
      catchError((e: HttpException) => {
        if (e instanceof EntityNotFoundError)
          throw new HttpException(
            { name: e.name, message: e.message } as ErrorDTO,
            HttpStatus.NOT_FOUND,
            { cause: e },
          );
        throw e;
      }),
    );
  }
}
