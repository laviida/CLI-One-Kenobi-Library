export const enum ENV {
  DEV = 'DEV',
  PRE = 'PRE',
  PROD = 'PROD',
}
