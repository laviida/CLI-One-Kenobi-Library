import { HttpException, HttpStatus, Injectable } from '@nestjs/common';
import { PassportStrategy } from '@nestjs/passport';
import { ExtractJwt, Strategy } from 'passport-jwt';
import { Observable, firstValueFrom } from 'rxjs';
import { TokenPayload } from '../dto/token.dto';
import environment from '@environments/environment';
import { UsersService } from '@application/users/users.service';
import { User } from '@controller/users/entities/user.entity';

@Injectable()
export class JwtPasswordStrategy extends PassportStrategy(
  Strategy,
  'jwt.password',
) {
  constructor(private usersService: UsersService) {
    super({
      jwtFromRequest: ExtractJwt.fromAuthHeaderAsBearerToken(),
      passReqToCallback: true,
      secretOrKeyProvider: async (
        request,
        rawJwtToken: string,
        done: (...any) => any,
      ) => {
        request['token'] = rawJwtToken;
        done(null, environment().httpConfig.token.secret);
      },
      ignoreExpiration: false,
    });
  }

  public async validate(
    request: Request,
    decodedToken: TokenPayload,
  ): Promise<User> {
    if (!decodedToken?.resetPassword)
      throw new HttpException(
        'Bearer Token must be a reset password token',
        HttpStatus.FORBIDDEN,
      );

    const user: User = await firstValueFrom(
      this.usersService.find({
        limit: 1,
        where: { id: decodedToken?.user?.id },
        orFail: false,
      }) as Observable<User>,
    );

    request['user'] = user;

    return request['user'];
  }
}
