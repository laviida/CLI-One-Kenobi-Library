import { UserFilterBy } from '@controller/users/entities/user.entity';
import { PageOptionsDto } from '@core/database/dto/pagination-options.dto';
import { ApiPropertyOptional } from '@nestjs/swagger';
import { IsEnum, IsOptional } from 'class-validator';

export class UserPageOptionsDto extends PageOptionsDto {
  @ApiPropertyOptional({ enum: UserFilterBy, default: UserFilterBy.id })
  @IsEnum(UserFilterBy)
  @IsOptional()
  readonly orderBy?: UserFilterBy = UserFilterBy.id;
}
